import { GoogleGenAI } from "@google/genai";
import { Habit } from "../types";
import { getTodayISO } from "../utils/dateUtils";

const API_KEY = process.env.API_KEY || '';

export const generateHabitInsights = async (habits: Habit[]): Promise<string> => {
  if (!API_KEY) {
    throw new Error("API Key is missing");
  }

  const ai = new GoogleGenAI({ apiKey: API_KEY });
  const today = getTodayISO();

  // Prepare a summary of habits for the AI
  const habitsSummary = habits.map(h => {
    const completionsLast7Days = h.completedDates.filter(d => {
      const date = new Date(d);
      const now = new Date();
      const diffTime = Math.abs(now.getTime() - date.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays <= 7;
    }).length;

    return `- ${h.title} (${h.category}): Completed ${completionsLast7Days} times in the last 7 days. Target: ${h.targetPerWeek}/week. Total completions: ${h.completedDates.length}.`;
  }).join('\n');

  const prompt = `
    You are an expert habit coach. Analyze the user's habit data below.
    Today is ${today}.
    
    User's Habits:
    ${habitsSummary}
    
    Task:
    Provide 3 concise, motivating, and specific insights or tips to help the user improve their consistency. 
    Focus on positive reinforcement and actionable advice. 
    Do not use markdown formatting like **bold** or # headers, just plain text with bullet points or emojis.
    Keep the response under 100 words.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    return response.text || "Keep going! You are doing great.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to generate insights. Please check your connection.");
  }
};
